var common_version = "8.0.3";
/*
************************************************
 * common.js
 * For common utility functions
 * Note: Do not put any comments as the starting line
************************************************
*/

// Check is the value is a URI
function isURIResource(value)
{
    var isURI = false;
    
    if (value.length == 0)
    	return false;
   
   value = value.toLowerCase();
   
   if (value.match("^http://*|^https://*|^file://*|^rtsp://*|^rtsps://*")) 
   		isURI = true;
   else if (value.indexOf(".jsp") != -1)
   		isURI = true;
   else if (value.substring(0,1) == "." || value.substring(0, 2) == "..")
   		isURI = true;

   return isURI;
}

function getGrammarURI(value,isDTMF)
{
    var grammarURI = "";
    
    if (isURIResource(value))
    	grammarURI = encodeURI(value);
    else if (isDTMF == false) //Voice Grammar
    	grammarURI = AppState.GRAMMARFILEDIR + '/' + AppState.APP_ASR_LANGUAGE + '/' + value;
    else //DTMF
    	grammarURI = AppState.GRAMMARFILEDIR + '/DTMF/' + value;
    
    return grammarURI;
}

function getGBuilderGrammarURI(value, isDTMF)
{
	if ( value == undefined || (value.indexOf("/") == -1 && value.indexOf("\\") == -1 ) ) {
		return value;
	}
	
	var	nSlashPos		= -1;
	var strGrammarURI	= "";
	var strGrammarFile	= "";
		
	nSlashPos = value.lastIndexOf( "/" );
	
	strGrammarFile = value.substr( nSlashPos, value.length - nSlashPos - 1 );
	strGrammarFile = strGrammarFile.substr( 0, strGrammarFile.lastIndexOf(".") );
	strGrammarFile += ".grxml";
		
	// pick up the grxml file name from the input value. GRXML files are expected to be in the 
	// "Resources/Grammars/<language> folder only
	strGrammarURI = AppState.GRAMMARFILEDIR + "/" + AppState.APP_ASR_LANGUAGE + "/" + strGrammarFile;
	strGrammarURI = strGrammarURI.replace( "//", "/" );
	
    if ( isDTMF == true ) {
    	strGrammarURI = strGrammarURI.replace( '/' + AppState.APP_LANGUAGE + '/', '/' + "DTMF" + '/');
    }
    
    return strGrammarURI;
}


function getAudioURI(value)
{
    var audioURI = "";
    
    if (isURIResource(value))
    	audioURI = value;
    else
    	audioURI = AppState.VOXFILEDIR + '/' + AppState.APP_LANGUAGE + '/' + value;
    
    return audioURI;
}

function checkIsObject(result) 
{
	if(result instanceof Object){
		return true;
	}
	return false;
}

function getDNIS()
{

	var address = "";
	
	// OCN takes precedence if available
	var ocn = session.connection.redirect[0];
	if (typeof ocn != 'undefined' && ocn != null) {
		address = ocn.uri;
	} 
	
	if (address == "") {
		address = session.connection.local.uri;
	}

	return getUserPart(address);
}

function getANI()
{

	var address = "";
	
	// this header takes precedence if available
	var pai = session.connection.protocol.sip.headers['p-asserted-identity'];
	if (typeof pai != 'undefined' && pai != null) {
		address = pai;
	} 
	
	if (address == "") {
		address = session.connection.remote.uri;
	}

	return getUserPart(address);
}

function getUserPart(address)
{
	var re = new RegExp("(?:sip|sips|tel):([^@]+)@.*");
	var result = re.exec(address);
	
	if (result == null || result.length < 2) return "";
	
	return result[1];

}

// try to convert a string to a number
function toNumber(value) { 
	
	if (typeof value == "number") {
		return value;
	}
	
	if (typeof value == "string") {
		var num = new Number(value);
		
		// test for not-a-number
		if (!isNaN(num)) {
			return num.valueOf();
		} else {
			return value;
		}
	}
	
	// return the original value by default
	return value;
	
}

function resetLanguage() {
    AppState.APP_LANGUAGE = AppState.PREV_APP_LANGUAGE;
    AppState.APP_ASR_LANGUAGE = AppState.PREV_APP_ASR_LANGUAGE;
}

function getCaptureLocation(location, prefix) {
	
	if (location.length == 0) return prefix;
	
	var endChar = location.charAt(location.length - 1);
	if (endChar != '\\' || endChar != '/') {
		location = location + '/';
	}
	
	return location + prefix;
	
}

function br_getLoginRequest(username, password) {
	
	var loginRequest = new Object();
	var loginRequestBody = new Object();
	            
	loginRequestBody.username = username;
	loginRequestBody.password = password;
	            
	loginRequest["login-request"] = loginRequestBody;
	
	return loginRequest;
	
}

function br_getSessionId(loginResponse) {
	
	if (typeof loginResponse == 'undefined' || loginResponse == null ||
		typeof loginResponse['login-response'] == 'undefined' || loginResponse == null ||
		typeof loginResponse['login-response']['sessionid'] == 'undefined' || loginResponse['login-response']['sessionid'] == null) {
		
		return null;
	}
	
	return loginResponse['login-response']['sessionid'];
}

function br_getPackageInfoRequest(sessionid) {
	
	var getPackageInfoRequest = new Object();
	var getPackageInfoRequestBody = new Object();
			       
	getPackageInfoRequestBody.sessionid = sessionid;
	
	getPackageInfoRequest["get-package-info-request"] = getPackageInfoRequestBody;
	
	return getPackageInfoRequest;
}

function br_getLocation(packageInfoResponse) {
	
	if (typeof packageInfoResponse == 'undefined' || packageInfoResponse == null ||
		typeof packageInfoResponse['get-package-info-response'] == 'undefined' || 
		packageInfoResponse['get-package-info-response'] == null || 
		typeof packageInfoResponse['get-package-info-response']['package-info'] == 'undefined' || 
		packageInfoResponse['get-package-info-response']['package-info'] == null || 
		typeof packageInfoResponse['get-package-info-response']['package-info']['location'] == 'undefined' || 
		packageInfoResponse['get-package-info-response']['package-info']['location'] == null)
	{
		return null;
	}
	
	var locationList = 	packageInfoResponse['get-package-info-response']['package-info']['location'];
	if (locationList.length == 0) {
		return null;
	}
	
	if (typeof locationList == 'string') {
		return locationList;
	} else {
		return locationList[0];
	}
}

function br_getLogoutRequest(sessionid) {
	
	var logoutRequest = new Object();
	var logoutRequestBody = new Object();
    
	logoutRequestBody.sessionid = sessionid;
	
	logoutRequest["logout-request"] = logoutRequestBody;
	
	return logoutRequest;
}

function br_initKbRequest() {
	
	var kbRequest = new Object();
	var kbRequestBody = new Object();
	    
	var inOutFacts = new Object();
	var namedFact = new Array();
	    
	inOutFacts['named-fact'] = namedFact;
	kbRequestBody['inOutFacts'] = inOutFacts;
	    
	kbRequest['knowledgebase-request'] = kbRequestBody;
	
	return kbRequest;
}

function br_addFact(kbRequest, fact) {
	
	var fArray = kbRequest['knowledgebase-request']['inOutFacts']['named-fact'];
	fArray.push(fact);
	
}

function br_getResultFacts(result) {
	
	if (typeof result == 'undefined' || result == null ||
		typeof result['knowledgebase-response'] == 'undefined' || result['knowledgebase-response'] == null || 
		typeof result['knowledgebase-response']['inOutFacts'] == 'undefined' || result['knowledgebase-response']['inOutFacts'] == null || 
		typeof result['knowledgebase-response']['inOutFacts']['named-fact'] == 'undefined' || 
		result['knowledgebase-response']['inOutFacts']['named-fact'] == null) {
		
		return null;
	}
	
	return result['knowledgebase-response']['inOutFacts']['named-fact'];
}

function getContextServicesUserName() {	
	return (typeof _data.context_management_services_username == undefined ? '' : _data.context_management_services_username);
}	

function getContextServicesPassword() {	
	return (typeof _data.context_management_services_password == undefined ? '' : _data.context_management_services_password);
}	

