
function getFirstNonCustomerDevice(ixn)
{
	var partyList = _genesys.ixn.interactions[ixn].parties;
	var element ;
		
		for (element in partyList )
		{			
			if(_genesys.ixn.interactions[0].parties[element].devicetype != "customer"){
			    return  _genesys.ixn.interactions[0].parties[element].device;
			}						
		}		
		return null;
		
}


