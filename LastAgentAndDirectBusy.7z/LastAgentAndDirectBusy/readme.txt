The project implements the Last Called Agent functionality. 
If no agent is available the treatment offers the options:

1. Request a callback
2. Wait
3. Leave a voicemail

Second call (or a callback preview) should be routed to the Last Called Agent.

VOBs:

last_agent_001.vox	Welcome.  Please enter your four digit account number
last_agent_002.vox	Ok, got it.
last_agent_003.vox	Please hold while I transfer your call to an agent .... 
last_agent_004.vox	Sorry, all of our agents are currently busy.  Please hold for the next available agent.
last_agent_005.vox	Would you like to be connected to the agent that you spoke with previously?  For yes, press 1.  For no, press 2.
last_agent_006.vox	Ok, checking agent availability�
last_agent_007.vox	Sorry, your agent is not available at the moment.  To have the agent call you back, press 1.  To leave a voicemail for the agent, press 2.  Or just wait on the line for the agent.
last_agent_008.vox	Thank you, your callback request has been registered.  The agent will call you back soon.  Goodbye.
last_agent_009.vox	Ok, to leave a voicemail for the agent, being speaking at the tone.  When you are finished, you can simply hang up or press pound.
last_agent_010.vox	Your voicemail has been recorded and will be delivered to the agent.  Thank you for calling, goodbye. 
last_agent_011.vox	Sorry, I didn't get that.

