var version = "8.0.4";

/**
 * This function will call the locale specific PlayBuiltinType function.
 * 
 * @param locale The locale language ID. e.g. en-US
 * @param voxFileDir The audio file directory.
 * @param value The value to translate.
 * @param type The type of the value.
 * @param format The output format [optional].
 * 
 * @return An array of URL strings.
 */
function PlayPromptSwitch(locale, voxFileDir, value, type, format)
{
	// The audio directory path for the specified language.
	var promptUrl = voxFileDir + "/" + locale + "/";

	// removes dash(-) and single quotes(').
	// i.e. 'en-US' >>> enUS
	locale = locale.replace('-','').replace(/'/g,"");

	var resultArray;
	// Invoke the locale specific PlayBuiltinType function. 
	// i.e. enUSPlayBuiltinType() from the en-US.js file.
	if (!(typeof format == 'undefined'))
		eval( "resultArray = " + locale + "PlayBuiltinType(\'"+ value +"\', \'"+ type +"\', \'"+ promptUrl +"\', \'"+ format +"\')" );
	else
		eval( "resultArray = " + locale + "PlayBuiltinType(\'"+ value +"\', \'"+ type +"\', \'"+ promptUrl +"\')" );

	return resultArray;
}

/**
 * Dummy class to hold constants
 */
function Format() {}
