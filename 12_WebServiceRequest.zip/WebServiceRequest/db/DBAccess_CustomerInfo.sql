SELECT TOP 1  "dbo"."Contact"."Id", "dbo"."Contact"."StrAttribute1", "dbo"."Contact"."StrAttribute4", "dbo"."Contact"."StrAttribute6"
 FROM 
 "dbo"."Contact"
 WHERE 
"dbo"."Contact"."StrAttribute3" = {system.ANI}